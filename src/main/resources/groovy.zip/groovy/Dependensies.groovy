package groovy
/**
 * User: artem.smirnov
 * Date: 19.11.2015
 * Time: 10:58
 */

//@Grab(group = 'org.codehaus.groovy.modules.http-builder', module = 'http-builder', version = '0.7')
//@Grab(group = 'org.apache.httpcomponents', module = 'httpclient', version = '4.5')
//@Grab(group='org.jsoup', module='jsoup', version='1.8.3')
//@Grab(group='com.fasterxml.jackson.core', module='jackson-databind', version='2.6.2')
//@Grab(group = 'commons-io', module = 'commons-io', version = '2.4')
//@Grab(group='ch.qos.logback', module='logback-classic', version='1.0.13')
//@Grab(group='com.frostwire', module='jlibtorrent', version='1.1.0.31')
//@Grab(group='com.frostwire', module='jlibtorrent-windows', version='1.1.0.31')

class Dependensies {
}
