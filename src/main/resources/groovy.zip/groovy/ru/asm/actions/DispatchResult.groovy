package groovy.ru.asm.actions

/**
 * User: artem.smirnov
 * Date: 16.06.2016
 * Time: 10:12
 */
enum DispatchResult {
    SUCCESSFUL,
    ERROR,
    EXIT
}
