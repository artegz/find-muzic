package groovy.ru.asm.actions

/**
 * User: artem.smirnov
 * Date: 16.06.2016
 * Time: 10:14
 */
interface UserAction {

    DispatchResult proceedAction(String[] params)

}