package groovy.ru.asm.tools

/**
 * User: artem.smirnov
 * Date: 15.03.2017
 * Time: 16:44
 */
class FetchPlaylistTool {
}
